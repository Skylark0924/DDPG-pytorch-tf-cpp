
Q_LEN = 10

